/**
 * @file
 * CMS theme behaviors.
 */

(($, Drupal) => {
  /**
   * Remove redundant title tag text from toggle button.
   */
  Drupal.behaviors.cmsThemeOntario = {
    attach(context) {
      // Script to remove the redundant title tag text from the toggle button in the frontend view of contrib
      // this is to serve an accessibility rule
      $(
        ".toolbar-icon.toolbar-icon-toggle-vertical, .toolbar-icon.toolbar-icon-toggle-horizontal"
      ).removeAttr("title");

      // Accessibility improvements for Gazette and LRD
      const $dateFrom = $("#edit-date-from", context);
      const $dateTo = $("#edit-date-to", context);

      const lang = $("html").attr("lang");

      const helpText =
        lang === "fr"
          ? "Veuillez entrer la date au format AAAA/MM/JJ"
          : "Please enter the date in YYYY/MM/DD format.";

      if ($dateFrom.length) {
        $dateFrom.attr({
          "aria-describedby": "date-from-help"
        });
        $dateFrom.after(
          `<small id="date-from-help" class="show-for-sr" aria-hidden="true">${helpText}</small>`
        );
      }

      if ($dateTo.length) {
        $dateTo.attr({
          "aria-describedby": "date-to-help"
        });
        $dateTo.after(
          `<small id="date-to-help" class="show-for-sr" aria-hidden="true">${helpText}</small>`
        );
      }
    }
  };
})(jQuery, Drupal);
