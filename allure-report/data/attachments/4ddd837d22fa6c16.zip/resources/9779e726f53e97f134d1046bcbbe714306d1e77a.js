(function($, Drupal, drupalSettings) {
  Drupal.behaviors.onesiteDatalayer = {
    attach() {
      if (this.attached) {
        return;
      }
      this.attached = true;
      // Google Tag Manager page view data layer
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "pageview",
        archived: drupalSettings.onesiteDataLayer.archived,
        contentTypeTag: drupalSettings.onesiteDataLayer.contentTypeTag,
        firstPublishedDate: drupalSettings.onesiteDataLayer.firstPublishedDate,
        lastUpdatedDate: drupalSettings.onesiteDataLayer.lastUpdatedDate,
        ministryTag: drupalSettings.onesiteDataLayer.ministryTag,
        pageTitle: drupalSettings.onesiteDataLayer.pageTitle,
        relativeUrl: drupalSettings.onesiteDataLayer.relativeUrl,
        topicTag: drupalSettings.onesiteDataLayer.topicTag,
        url: drupalSettings.onesiteDataLayer.url
      });
      // End Google Tag Manager page view data layer
      // Google Tag Manager Menu click data layer
      const menuConfigs = [
        { id: "navigation", openClass: "navigation--open", menuName: "topics" },
        {
          id: "sign-in-navigation",
          openClass: "sign-in-navigation--open",
          menuName: "sign in"
        }
      ];

      menuConfigs.forEach(({ id, openClass, menuName }) => {
        const node = document.getElementById(id);
        if (!node) return;
        const menuObserver = new MutationObserver(mutationsList => {
          if (
            mutationsList.some(
              mutation =>
                mutation.type === "attributes" &&
                mutation.attributeName === "class"
            )
          ) {
            const menuState = node.classList.contains(openClass)
              ? "open"
              : "close";
            if (menuState === "open") {
              window.dataLayer = window.dataLayer || [];
              window.dataLayer.push({
                event: "click_menu",
                menu_state: menuState,
                menu_name: menuName
              });
            }
          }
        });
        menuObserver.observe(node, {
          attributes: true,
          attributeFilter: ["class"]
        });

        $(node).on("click", "a", function() {
          window.dataLayer = window.dataLayer || [];
          window.dataLayer.push({
            event: "click_menu_link",
            menu_name: menuName,
            link_text: $(this)
              .find(".menu-item-label")
              .text()
              .trim(),
            link_url: $(this).attr("href")
          });
        });
      });
      // End Google Tag Manager Menu click data layer
      // Google Tag Manager related link click data layer
      $(".sidebar__content a").on("click", function() {
        const linkText = $(this).text();
        const linkUrl = $(this).attr("href");
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: "click_related_link",
          link_text: linkText,
          link_url: linkUrl
        });
      });
      // End Google Tag Manager related link click data layer
      // Google Tag Manager OIC search results data layer
      $("#edit-submit-oic-result").on("click", function() {
        const queryParams = new URLSearchParams(window.location.search);
        const queryValue = queryParams.get("query")
          ? String(queryParams.get("query")).toLowerCase()
          : null;
        window.dataLayer = window.dataLayer || [];
        if (queryValue) {
          window.dataLayer.push({
            event: "product_search",
            product_name: "orders in council",
            product_search_term: queryValue
          });
        }
      });
      // End Google Tag Manager OIC search data layer
    }
  };
})(jQuery, Drupal, drupalSettings);
