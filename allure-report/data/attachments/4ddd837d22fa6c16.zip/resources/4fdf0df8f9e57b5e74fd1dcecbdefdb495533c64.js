/**
 * Script for add Name to the Admin Search Toolbar
 * and add aria-label, value attributes to the
 * toolbar orientation toggle buttons.
 */

/**
 * @file
 * Ontario 2021 theme behaviors.
 */
(function(Drupal, once) {
  function updateToggleAttributes(el) {
    if (el.classList.contains("toolbar-icon-toggle-vertical")) {
      el.setAttribute("aria-label", "Toggle vertical orientation");
      el.setAttribute("value", "vertical");
      el.setAttribute("data-once", "add-toggle-vertical-aria-label");
    } else if (el.classList.contains("toolbar-icon-toggle-horizontal")) {
      el.setAttribute("aria-label", "Toggle horizontal orientation");
      el.setAttribute("value", "horizontal");
      el.setAttribute("data-once", "add-toggle-horizontal-aria-label");
    }
  }

  function watchToggleAttributes(el) {
    updateToggleAttributes(el);
    new MutationObserver(function() {
      updateToggleAttributes(el);
    }).observe(el, { attributes: true, attributeFilter: ["class"] });
  }

  Drupal.behaviors.addAdminToolbarSearchName = {
    attach(context) {
      const ctx = context || document;
      once("add-search-name", "#admin-toolbar-search-input", ctx).forEach(
        function(el) {
          el.setAttribute("name", "search");
        }
      );
      once(
        "add-toggle-attributes",
        ".toolbar-icon.toolbar-icon-toggle-vertical, .toolbar-icon.toolbar-icon-toggle-horizontal",
        ctx
      ).forEach(watchToggleAttributes);
    }
  };
})(Drupal, once);
