(function(Drupal, once) {
  Drupal.behaviors.replyYesTrigger = {
    attach(context) {
      const { body } = document;
      if (
        !body.classList.contains("path-feedback-contact-us") &&
        !body.classList.contains("path-fr-commentaires-pour-nous-joindre")
      ) {
        return;
      }
      const yesRadio = context.querySelector(
        "#edit-would-you-like-a-reply-radio-yes"
      );

      if (!yesRadio) {
        return;
      }

      once("reply-yes-trigger", yesRadio).forEach(radio => {
        radio.addEventListener("change", () => {
          if (!radio.checked) {
            return;
          }

          document.body.classList.add("reply-yes-selected");

          const emailField = document.querySelector("#edit-email");
          if (emailField) {
            emailField.focus();
          }
        });
      });
    }
  };
})(Drupal, once);
