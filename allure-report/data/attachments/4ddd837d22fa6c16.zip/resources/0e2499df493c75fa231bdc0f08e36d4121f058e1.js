/**
 * Custom behaviors for the error Status message.
 */

(function($, Drupal) {
  Drupal.behaviors.focusStatusMessage = {
    attach(context) {
      const $alertBox = $("#status_alert", context);
      const isInConfirmation = $alertBox.closest(".webform-confirmation")
        .length;

      if (
        ($(".webform-progress").length ||
          $(".webform-submission-form").length) &&
        !isInConfirmation
      ) {
        return;
      }

      setTimeout(function() {
        if ($alertBox.length && !$alertBox.hasClass("focus-set")) {
          $alertBox.attr("tabindex", "-1");
          $alertBox.focus();
          $alertBox.addClass("focus-set");
        }
      }, 300);
    }
  };
})(jQuery, Drupal);
