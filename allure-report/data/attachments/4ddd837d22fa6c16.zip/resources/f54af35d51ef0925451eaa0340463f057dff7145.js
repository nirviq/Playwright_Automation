/**
 * @file
 * Custom behaviors for Ontario.ca website.
 *
 * This script enhances user experience, accessibility, and security.
 */

(function($, Drupal) {
  /**
   * Attaches custom behaviors to the Ontario.ca website.
   */
  Drupal.behaviors.ontario2021 = {
    attach() {
      // For security/phishing reasons, add rel="noopener noreferrer" to all
      // links with target="_blank".
      $('a[target="_blank"]:not([rel])').attr("rel", "noopener noreferrer");

      /**
       * Function to handle the exit.
       * @param {object} e - The event object passed by the event listener (e.g., a click event).
       * @param {string} url - The URL to open in a new tab.
       */
      function getAway(e, url) {
        e.preventDefault();
        window.open(url, "_newtab");
        window.location.replace("https://google.ca");
      }

      // For the back to top button on the same page as a specialty button.
      const $chatbotButton = $(".chatbot-button");
      if ($chatbotButton.length > 0) {
        const backToTopNewPosition = $chatbotButton.outerHeight(true) + 15;
        $("#back-to-top-button").css({
          bottom: `calc(5% + ${backToTopNewPosition}px)`
        });

        // If the Exit button exists, allow users to get away by pressing it.
        // The difference between exit and chat button is that the first one uses
        // an anchor tag and the chat uses a button tag.
        const $exitButton = $("a.chatbot-button").first();

        if ($exitButton.length > 0) {
          const exitUrl = $exitButton.attr("href");

          if (exitUrl) {
            $exitButton.click(e => {
              getAway(e, exitUrl);
            });

            $(document).keyup(e => {
              if (e.key === "Escape" || e.keyCode === 27) {
                getAway(e, exitUrl);
              }
            });
          }
        }
      }

      // For the back to top button on the same page as the recaptcha button
      if ($("script[src*='recaptcha_v3']").length > 0) {
        $("#back-to-top-button").addClass("back-to-top--recaptcha");
        $(".back-to-top--recaptcha").css({ bottom: `calc(5% + ${65}px)` }); // 65px is the approx. height of the recaptcha button
      }

      // Based on Design System's recommendation of adding tabindex to the table tag used in the content area.
      const contentTable = $(".main-content table");
      if (contentTable.length > 0) {
        contentTable.attr("tabindex", "0");
      }

      // Lists with the type attribute
      $("ol").each(function() {
        const listType = $(this).attr("type");
        if (listType === "A" || listType === "I") {
          $(this).addClass("upper");
        }
      });

      // Adding a classname to any a tag with a nested img
      // to target using CSS
      const imgTags = document.querySelectorAll("a > img");
      const figureTags = document.querySelectorAll("a > figure");
      const divTags = document.querySelectorAll("a > div");

      const elements = [...imgTags, ...figureTags, ...divTags];
      elements.forEach(function(element) {
        const aTag = element.parentNode;
        aTag.classList.add("link-wrapper");
      });
    }
  };

  // Custom loading indicator to fit the Design System theme.
  // Overrides web/core/misc/ajax.js line 426
  Drupal.theme.ajaxProgressIndicatorFullscreen = function() {
    const language = document.documentElement.lang
      .toLowerCase()
      .substring(0, 2);
    const loadingText = language === "fr" ? "Chargement" : "Loading";

    return `<div class='loading-indicator__overlay' aria-hidden='false' role='alert' aria-live='assertive'><div class='loading-indicator'><svg class='loading-indicator__spinner' viewBox='25 25 50 50' xmlns='http://www.w3.org/2000/svg'><circle fill='none' stroke-width='4' stroke-linecap='round' cx='50' cy='50' r='20'></circle></svg><p>${loadingText}</p></div></div>`;
  };

  Drupal.Ajax.prototype.setProgressIndicatorFullscreen = function() {
    this.progress.element = $(Drupal.theme("ajaxProgressIndicatorFullscreen"));
    $("body").append(this.progress.element);
  };

  function updateTableWidths() {
    const tables = document.querySelectorAll("table.full-width");

    tables.forEach(function(table) {
      const wrapper = table.closest("div");
      const tableWidth = table.getBoundingClientRect().width;
      const wrapperWidth = wrapper ? wrapper.getBoundingClientRect().width : 0;
      const parentWidth =
        wrapper?.parentElement?.getBoundingClientRect().width || 0;
      const wrapperIsLessThan100Percent = wrapperWidth < parentWidth - 1;

      if (tableWidth > 1152 || wrapperIsLessThan100Percent) {
        table.classList.remove("full-width");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", updateTableWidths);
  window.addEventListener("resize", updateTableWidths);
})(jQuery, Drupal);
