(function(jQuery, Drupal) {
  Drupal.behaviors.focusResultsHeaderOnAjax = {
    attach() {
      // Listen for AJAX completions
      jQuery(document).ajaxComplete(() => {
        const header = document.querySelector("#numberOfResultsHeader");
        if (!(header instanceof HTMLElement)) return;
        const hadTabindex = header.hasAttribute("tabindex");
        if (!hadTabindex) header.setAttribute("tabindex", "-1");
        setTimeout(() => {
          header.focus();
        }, 50); // small delay ensures the header is in the DOM and visible

        header.addEventListener(
          "blur",
          () => {
            if (!hadTabindex) header.removeAttribute("tabindex");
          },
          { once: true }
        );
      });
    }
  };
})(jQuery, Drupal);
