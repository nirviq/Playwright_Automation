/**
 * @file
 * Webform a11y improvements
 */
(function($, Drupal, once) {
  Drupal.behaviors.webformRequiredFix = {
    attach(context) {
      once(
        "webform-required-fix",
        'input[type="radio"], input[type="checkbox"]',
        context
      ).forEach(input => {
        // Watch for required attribute being added
        const observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (
              mutation.type === "attributes" &&
              mutation.attributeName === "required"
            ) {
              input.removeAttribute("required");
              input.removeAttribute("aria-required");
            }
          });
        });
        observer.observe(input, {
          attributes: true,
          attributeFilter: ["required"]
        });
      });
    }
  };

  function focusElementOnce(el) {
    if (!el) return;

    if (el.classList.contains("focus-set")) {
      return; // Already focused by this behavior.
    }

    // If not naturally focusable, add tabindex="-1" (doesn't alter tab order).
    const naturallyFocusableSelectors = [
      "a[href]",
      "button",
      "input",
      "textarea",
      "select",
      "[tabindex]",
      "[contenteditable='true']"
    ];
    const isNaturallyFocusable = naturallyFocusableSelectors.some(sel =>
      el.matches(sel)
    );
    if (!isNaturallyFocusable) {
      el.setAttribute("tabindex", "-1");
    }

    el.focus();
    el.classList.add("focus-set");
  }

  Drupal.behaviors.focusWebFormRules = {
    attach(context) {
      // Only proceed if the page contains a webform submission form.
      const formScopes = once(
        "focus-webform-scope",
        context.querySelectorAll(".webform-submission-form")
      );
      if (formScopes.length === 0) {
        return;
      }
      setTimeout(function() {
        // 1) Status alert anywhere on the page.
        const target =
          document.getElementById("status_alert") ||
          // 2) Multi-step progress within current context.
          context.querySelector(".webform-progress") ||
          // 3) First visible <h1> in context.
          Array.from(context.querySelectorAll("h1")).find(
            h => h.offsetParent !== null
          ) ||
          null;

        focusElementOnce(target);
      }, 300);
    }
  };
  Drupal.behaviors.webformA11yConditionalAnnounce = {
    attach(context) {
      const containers = once(
        "webform-a11y",
        ".js-form-item, .form-item",
        context
      );
      const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
          if (mutation.attributeName === "style") {
            const el = mutation.target;
            if ($(el).css("display") !== "none") {
              if (!$(el).data("a11yProcessed")) {
                $(el).data("a11yProcessed", true);
                $(el)
                  .attr("role", "alert")
                  .attr("aria-live", "polite");
                const firstField = $(el)
                  .find("input, select, textarea")
                  .first();
                if (firstField.length) {
                  firstField.attr("tabindex", "-1").focus();
                }
              }
            }
          }
        });
      });
      $(containers).each(function() {
        observer.observe(this, {
          attributes: true,
          attributeFilter: ["style"]
        });
      });
    }
  };
})(jQuery, Drupal, once);
