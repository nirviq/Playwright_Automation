/**
 * @file
 * Ontario.ca search autosuggest configs.
 */

(function(Drupal, drupalSettings) {
  // Assigning the onesite_search_autosuggest from drupalSettings value to the
  // window global object.
  const config = drupalSettings.onesite_ontario_search_autosuggest || {};

  if (
    config.apiConfig &&
    config.apiConfig.engineName &&
    config.apiConfig.endpointBase
  ) {
    window.apiConfig = config.apiConfig;
  } else {
    window.apiConfig = {};
  }

  window.endpointConfig = config.endpointConfig || {};
})(Drupal, drupalSettings);
