/**
 * @file
 * Table of contents script
 */

(function($, Drupal) {
  /**
   * Creates a list item (`<li>`) containing an anchor (`<a>`) element.
   *
   * @param {string} title - The text content for the anchor element.
   * @param {string} link - The URL that the anchor element should link to.
   * @param {string} [listItemClass] - Optional. A CSS class to apply to the list item.
   * @return {HTMLLIElement} A list item element containing an anchor tag with the specified title and link.
   */
  function createTocItem(title, link, listItemClass) {
    const listItem = document.createElement("li");
    const listItemAnchor = document.createElement("a");

    // Set list item class only if it is passed as an argument.
    if (listItemClass) {
      listItem.setAttribute("class", listItemClass);
    }
    listItemAnchor.href = link;

    listItemAnchor.innerHTML = title;
    listItem.appendChild(listItemAnchor);

    return listItem;
  }

  /**
   * Add list items to the 'On this page' template.
   */
  Drupal.behaviors.onThisPage = {
    attach() {
      const ToC = [];
      const tocElement = $(".toc");
      const related = $("#section-related");
      const bodyH2 = $(".body-field h2");

      bodyH2.each(function(index) {
        const el = $(this);
        // Add id attribute.
        el.attr("id", `section-${index}`);

        const link = `#${el.attr("id")}`;
        // Allow certain tags in the ToC, but filter out id from span tags.
        const filteredHtml = el
          .html()
          .replace(/<(?!\/?(abbr|cite|i|sup|sub|span)\b)[^>]*>/gi, "")
          .replace(/<span[^>]*\sid="[^"]*"[^>]*>/gi, "<span>");
        ToC.push(createTocItem(filteredHtml, link));
      });

      // If related section exists, add 'Related' and its associated class and
      // ID to the ToC. (Hidden by CSS on desktop view)
      if (Object.keys(related).length > 0) {
        const lang = window.location.pathname.startsWith("/fr/") ? "fr" : "en";
        ToC.push(
          createTocItem(
            lang === "fr" ? "Liens connexes" : "Related",
            "#section-related",
            "related-li"
          )
        );
      }

      // Populate the contents of the ToC element with all the list items.
      tocElement.html(ToC);

      // If the ToC is empty, hide the surrounding ToC HTML from the template.
      if (bodyH2.length === 0) {
        $(".toc__wrapper, .book__toc").hide();
      }
    }
  };
})(jQuery, Drupal);
