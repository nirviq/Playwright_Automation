(function($, Drupal) {
  /**
   * Function to change the updated date displayed on the frontend,
   * can be used in custom scripts by calling `updateDate('2025-12-31')`.
   */
  Drupal.behaviors.onesiteUpdatedDate = {
    attach() {
      window.updateDate = function(date, lang = null) {
        if (lang === null) {
          lang = window.location.pathname.startsWith("/fr/") ? "fr" : "en";
        }

        const monthsEn = [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December"
        ];
        const monthsFr = [
          "janvier",
          "février",
          "mars",
          "avril",
          "mai",
          "juin",
          "juillet",
          "août",
          "septembre",
          "octobre",
          "novembre",
          "décembre"
        ];

        const formatDisplayDate = (isoDate, locale) => {
          const [yearStr, monthStr, dayStr] = isoDate.split("-");
          const year = Number(yearStr);
          const monthIndex = Number(monthStr) - 1;
          const day = Number(dayStr);

          const months = locale === "fr" ? monthsFr : monthsEn;
          const monthName = months[monthIndex];

          return locale === "fr"
            ? `${day} ${monthName} ${year}`
            : `${monthName} ${day}, ${year}`;
        };

        const displayDate = formatDisplayDate(date, lang);

        const updatedDateElement = document.querySelector(
          "div.text-right:nth-child(1) > small:nth-child(1)"
        );
        if (updatedDateElement) {
          const text = updatedDateElement.textContent || "";
          const separator = ": ";
          if (text.includes(separator)) {
            const label = text.split(separator)[0];
            updatedDateElement.textContent = `${label}${separator}${displayDate}`;
          } else {
            updatedDateElement.textContent = displayDate;
          }
        }

        const updatedDateMeta = document.querySelector(
          'meta[property="article:modified_time"]'
        );
        if (updatedDateMeta) {
          updatedDateMeta.setAttribute("content", date);
        }
      };
    }
  };
})(jQuery, Drupal);
