/**
 * @file
 * Webform enhancements Additional details link expand/collapse script and
 * checkbox labels.
 */

(function($, Drupal, once) {
  /**
   * Webform enhancements.
   *
   * @namespace
   * @property {Object} webformEnhancements - The behavior object.
   */
  Drupal.behaviors.webformEnhancements = {
    /**
     * Attaches the click event to the additional details links to toggle
     * the 'is-open' class.
     *
     * @param {HTMLElement} context
     *   The DOM element or document to which the behavior is attached.
     */
    attach(context) {
      // Add click event to the 'Additional details' link
      $(
        "div.webform-element-more-link--checkbox a, div.webform-element-more-link--radio a",
        context
      ).click(function(e) {
        e.preventDefault();
        $(this)
          .closest(".js-webform-element-more")
          .toggleClass("is-open");
      });
      $(
        "div.webform-element-more-link--checkbox a, div.webform-element-more-link--radio a",
        context
      ).each(function() {
        $(this).addClass("webform-element-more-link--link");
      });

      // Webforms: apply a margin bottom to the description div if there is a "more" link
      $(".webform-submission-form .description").each(function() {
        if ($(this).find(".webform-element-more").length > 0) {
          $(this).css("margin-bottom", "0");
        }
      });

      // Webforms: after AJAX rebuilds, keep required classes in sync for file
      // upload labels and checkbox option labels based on js-form-wrapper
      // required attributes.
      const languageForRequiredLabel =
        document.documentElement.lang?.toLowerCase().substring(0, 2) ?? "en";
      const requiredText =
        languageForRequiredLabel === "fr" ? "obligatoire" : "required";
      function setLabelAsRequired(label) {
        const $label = $(label);
        $label
          .removeClass("js-form-optional form-optional")
          .addClass("js-form-required form-required");

        // If a status span already exists, normalize it to required text/class.
        const statusSpan = $label.find(
          ".checkbox-optional-span, .checkbox-required-span"
        )[0];
        if (statusSpan) {
          statusSpan.className = "checkbox-required-span";
          statusSpan.textContent = ` (${requiredText})`;
        }
      }

      $(context)
        .find(".js-form-wrapper")
        .addBack(".js-form-wrapper")
        .each(function() {
          const $wrapper = $(this);
          const wrapperIsRequired =
            $wrapper.attr("required") === "required" ||
            $wrapper.attr("aria-required") === "true" ||
            $wrapper.find(
              ".js-webform-states-hidden.js-form-wrapper[required='required'], .js-webform-states-hidden.js-form-wrapper[aria-required='true']"
            ).length > 0;

          if (!wrapperIsRequired) {
            return;
          }

          // Managed file field title label.
          $wrapper
            .find(".file__item > label.form-label, .file__item > label")
            .each(function() {
              setLabelAsRequired(this);
            });

          // Checkbox labels within this required wrapper.
          $wrapper.find("input[type=checkbox] + label").each(function() {
            setLabelAsRequired(this);
          });
        });

      // Handle case where .js-form-wrapper disappears on form error.
      // Find managed file fields via their ajax-wrapper parent and
      // check the preceding fieldset for a required class.
      $(context)
        .find(".js-form-type-managed-file")
        .each(function() {
          const $managedFile = $(this);
          const $ajaxWrapper = $managedFile.closest("[id^='ajax-wrapper']");
          if (!$ajaxWrapper.length) {
            return;
          }
          const $fieldset = $ajaxWrapper.prev("fieldset");
          if (!$fieldset.length || !$fieldset.hasClass("required")) {
            return;
          }

          // Managed file field title label.
          $managedFile.find("label.form-label, label").each(function() {
            setLabelAsRequired(this);
          });

          // Checkbox labels within this managed file wrapper.
          $managedFile.find("input[type=checkbox] + label").each(function() {
            setLabelAsRequired(this);
          });

          // Wrap $ajaxWrapper with a div.js-webform-states-hidden.js-form-wrapper when error occurs.
          if (
            $ajaxWrapper.parent("div.js-webform-states-hidden.js-form-wrapper")
              .length === 0
          ) {
            $ajaxWrapper.wrap(
              '<div class="js-webform-states-hidden js-form-wrapper"></div>'
            );
          }
          const $wrapperParent = $ajaxWrapper.parent(
            "div.js-webform-states-hidden.js-form-wrapper"
          );
          const $formScope = $ajaxWrapper.closest(
            "form, .webform-submission-form"
          );

          // Find the nearest preceding radio button relative to $ajaxWrapper.
          let $searchNode = $ajaxWrapper;
          let $precedingRadio = $();
          while (!$precedingRadio.length && $searchNode.length) {
            $precedingRadio = $searchNode
              .prevAll()
              .find('input[type="radio"]')
              .last();
            $searchNode = $searchNode.parent();
          }
          const radioName = $precedingRadio.attr("name");

          function updateAjaxWrapperVisibility() {
            if (!radioName) {
              return;
            }
            const checkedVal = $formScope
              .find(`input[type="radio"][name="${radioName}"]:checked`)
              .val();
            const checkedValLower =
              typeof checkedVal === "string" ? checkedVal.toLowerCase() : "";

            if (checkedValLower === "yes") {
              $wrapperParent.css("display", "block");
            } else if (checkedValLower === "no") {
              $wrapperParent.css("display", "none");
            }
          }

          // Set initial state and update it whenever the radio selection changes.
          updateAjaxWrapperVisibility();
          if (radioName) {
            const $radioInputs = $formScope.find(
              `input[type="radio"][name="${radioName}"]`
            );
            once(
              `ajax-wrapper-radio-toggle-${$ajaxWrapper.attr("id")}`,
              $radioInputs.get()
            ).forEach(radio => {
              $(radio).on("change", updateAjaxWrapperVisibility);
            });
          }
        });

      // Webforms: Function to check if a label spans more than two lines.
      function checkLabelLength(label) {
        const lineHeight = parseInt(label.css("line-height"), 10);
        const labelHeight = label.height();
        const numberOfLines = Math.round(labelHeight / lineHeight);
        return numberOfLines > 1.8;
      }

      // Webforms: Iterate through each form label and apply a class.
      $(".form-required.form-label, .form-optional.form-label").each(
        function() {
          const label = $(this);
          if (checkLabelLength(label)) {
            label.addClass("long-label");
          } else {
            label.removeClass("long-label");
          }
        }
      );

      // Webforms: Append required/optional label after a required/optional single checkbox.
      // Select all labels that directly follow a checkbox input & have class 'form-required'/'form-optional'
      const singleCheckboxLabel = document.querySelectorAll(
        ".webform-submission-form input[type=checkbox] + label.form-required, .webform-submission-form input[type=checkbox] + label.form-optional"
      );

      // Apply aria-hidden="true" to the <hr> tags to hide them from screen readers
      $(".webform-submission-form hr.progress-separator").attr(
        "aria-hidden",
        "true"
      );

      // Skip if no matching checkbox labels found.
      if (!singleCheckboxLabel) {
        return;
      }

      const language =
        document.documentElement.lang?.toLowerCase().substring(0, 2) ?? "en";

      // Loop through each label and append a span element (once only)
      once("checkbox-required-label", singleCheckboxLabel).forEach(label => {
        if ($(label).parents(".js-webform-checkboxes").length > 0) {
          // If this is part of the checkboxes element then the title will be marked as required/optional
          // No need to mark it on every single checkbox option as well
          return;
        }
        const isRequired = $(label).hasClass("form-required");
        const labels = {
          required: { fr: "obligatoire", en: "required" },
          optional: { fr: "facultative", en: "optional" }
        };
        const status = isRequired ? "required" : "optional";
        const langKey = language === "fr" ? "fr" : "en";
        const text = labels[status][langKey];
        const span = document.createElement("span");
        span.className = isRequired
          ? "checkbox-required-span"
          : "checkbox-optional-span";
        span.textContent = ` (${text})`;

        // Append the span to the label
        label.appendChild(span);
      });

      // Webform preview: replace <summary> with Ontario heading container.
      $(
        ".webform-submission-data--view-mode-preview details .webform-wizard-page-edit",
        context
      ).each(function() {
        const $editContainer = $(this);
        const $editInput = $editContainer.find("input").first();
        const $details = $editContainer.closest("details");
        const $summary = $details.find("> summary").first();
        if (!$summary.length || !$editInput.length) {
          return;
        }

        const headingText =
          $summary
            .find("span.summary")
            .first()
            .text()
            .trim() || $summary.text().trim();
        const $headingContainer = $(
          '<div class="ontario-summary-list-heading__container"></div>'
        );
        const $heading = $(
          '<h3 class="ontario-summary-list__heading"></h3>'
        ).text(headingText);
        const $buttons = $(
          '<div class="ontario-summary-list-heading__buttons"></div>'
        );
        const linkLabel = Drupal.t("Change");
        const $changeLink = $(
          '<a href="#" class="ontario-summary-list-change__button webform-summary-edit-link"></a>'
        ).text(linkLabel);

        $changeLink.on("click", function(e) {
          e.preventDefault();
          $editInput.trigger("click");
        });

        $headingContainer.append($heading);
        $buttons.append($changeLink);
        $headingContainer.append($buttons);
        $headingContainer.append($editContainer);
        $summary.remove();
        $details.prepend($headingContainer);
      });

      // Webform preview: replace details wrappers with Ontario summary list
      // containers.
      $(
        ".webform-submission-data--view-mode-preview details.webform-container-type-details",
        context
      ).each(function() {
        const $details = $(this);
        const $replacement = $('<div·class="ontario-summary-list"></div>');

        // Preserve non-class attributes like id/data-* used by scripts.
        $.each(this.attributes, function() {
          if (
            this &&
            this.name &&
            this.name !== "class" &&
            this.name !== "open"
          ) {
            $replacement.attr(this.name, this.value);
          }
        });

        $replacement.append($details.contents());
        $details.replaceWith($replacement);
      });
    }
  };
  Drupal.behaviors.addNoIntroBorderClass = {
    attach(context) {
      if (context.querySelector(".progress-tracker--without-back-button")) {
        once(
          "addNoIntroBorderClass",
          context.querySelectorAll(".row.intro.row--collapse")
        ).forEach(el => el.classList.add("no-intro-border"));
      }
    }
  };
})(jQuery, Drupal, once);
