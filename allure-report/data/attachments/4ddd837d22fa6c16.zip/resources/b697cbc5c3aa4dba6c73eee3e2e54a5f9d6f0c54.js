(function(Drupal, once) {
  Drupal.behaviors.addAriaLabelsToSearchButtons = {
    attach(context) {
      const exposedForms = once(
        "customAriaLabelEnhancements",
        ".views-exposed-form",
        context
      );
      exposedForms.forEach(function(form) {
        const gazetteSearchBtn = form.querySelector(
          "#edit-submit-gazette-result"
        );
        if (gazetteSearchBtn) {
          gazetteSearchBtn.setAttribute("aria-label", "Search Ontario Gazette");
        }
        const lrdSearchBtn = form.querySelector("#edit-submit-lrd-result");
        if (lrdSearchBtn) {
          lrdSearchBtn.setAttribute("aria-label", "Search Land Registration");
        }
        const oicSearchBtn = form.querySelector("#edit-submit-oic-result");
        if (oicSearchBtn) {
          oicSearchBtn.setAttribute("aria-label", "Search Orders in Council");
        }
      });
    }
  };
})(Drupal, once);
